package Assignment2;

public class MainBikeRide 
{
	public static void main(String[] args) {
		double[] output = bikeRide();
		System.out.println("Probability of finding the hostel by bike: " + output[0]);
		System.out.println("Expected costs: " + output[1]);
	}
	
	public static double[] bikeRide() {
		double[] output = new double[2];
		
		return output;
	}
}
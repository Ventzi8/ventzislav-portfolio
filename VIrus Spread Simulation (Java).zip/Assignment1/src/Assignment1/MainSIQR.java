package Assignment1;

public class MainSIQR 
{
	public static void main(String[] args) {
		double[] output = getSIQRPerformance();
		System.out.println("Final size: " + output[0]);
		System.out.println("Deceased: " + output[1]);
	}
	
	public static double[] getSIQRPerformance() {
		double[] output = new double[2];
		
		return output;
	}
}
